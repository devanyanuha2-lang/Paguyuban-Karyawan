PAGUYUBAN KARYAWAN - PROYEK ANDROID

Proyek ini dibuat berdasarkan desain UI yang dikirim pengguna.
Fitur utama:
- Login Aris Sutanto / password awal 1102589
- Lupa Username dan Lupa Password
- Setoran: klik nama -> nominal otomatis dari Pengaturan -> konfirmasi -> simpan
- Nominal dapat diubah tanpa mengubah transaksi lama
- Data Anggota
- Pengeluaran
- Laporan Bulanan dan Tahunan
- Arsip tahun
- Tutup tahun
- Saldo dan riwayat transaksi
- Cetak laporan; PDF dapat dipilih dari dialog cetak Android

MEMBUAT APK:
1. Buka folder proyek ini di Android Studio versi terbaru.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build APK(s).
4. APK debug akan berada di app/build/outputs/apk/debug/app-debug.apk.

CATATAN:
Versi ini menyimpan data lokal pada HP. Belum memakai database online/sinkronisasi antar-HP.

DATA AWAL: 32 karyawan (NIK + nama) telah dimasukkan dari daftar pengguna.

FINAL UPDATE: 32 data anggota resmi (NIK + nama) dipaksa tersedia melalui migrasi otomatis, termasuk pada data lokal aplikasi yang sebelumnya sudah pernah dibuka.

REVISI ANGGOTA: 32 data anggota awal; tambah anggota dengan NIK/nama; edit dan hapus anggota; penghapusan tidak menghapus riwayat transaksi.
